var files =
[
    [ "editorconfig.h", "editorconfig_8h.html", "editorconfig_8h" ],
    [ "editorconfig_handle.h", "editorconfig__handle_8h.html", "editorconfig__handle_8h" ]
];