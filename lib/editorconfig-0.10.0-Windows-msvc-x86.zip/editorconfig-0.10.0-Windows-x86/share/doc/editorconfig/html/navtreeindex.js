var NAVTREEINDEX =
{
"index.html":[],
"index.html":[0],
"pages.html":[1],
"editorconfig.html":[1,0],
"editorconfig-format.html":[1,1],
"files.html":[2,0],
"editorconfig_8h.html":[2,0,0],
"editorconfig__handle_8h.html":[2,0,1],
"globals.html":[2,1,0],
"globals_func.html":[2,1,1],
"globals_type.html":[2,1,2],
"globals_defs.html":[2,1,3]
};
