var pages =
[
    [ "EditorConfig Command", "editorconfig.html", null ],
    [ "EditorConfig File Format", "editorconfig-format.html", null ]
];