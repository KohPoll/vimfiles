var editorconfig__handle_8h =
[
    [ "editorconfig_handle", "editorconfig__handle_8h.html#a0c51d798e0e22051d0057a567245010c", null ],
    [ "editorconfig_handle_destroy", "editorconfig__handle_8h.html#add8960b396594d796843df56a6fd0cfe", null ],
    [ "editorconfig_handle_get_conf_file_name", "editorconfig__handle_8h.html#a5d8fd295880d6512751a7f3c840e3ce0", null ],
    [ "editorconfig_handle_get_err_file", "editorconfig__handle_8h.html#ae0c5207a1986dfea2f641008ddefdd93", null ],
    [ "editorconfig_handle_get_name_value", "editorconfig__handle_8h.html#ad8330caee21b6aaacfa9fc95792b0389", null ],
    [ "editorconfig_handle_get_name_value_count", "editorconfig__handle_8h.html#a5a589c0471ca6651d09823595ddd3ea2", null ],
    [ "editorconfig_handle_get_version", "editorconfig__handle_8h.html#a05b5ade439f00b2634a31c8b195365b7", null ],
    [ "editorconfig_handle_init", "editorconfig__handle_8h.html#a8e3f1681e835a2946ba93b341ebc3dca", null ],
    [ "editorconfig_handle_set_conf_file_name", "editorconfig__handle_8h.html#a345fc52f7cc06dc8d35685ef4904013b", null ],
    [ "editorconfig_handle_set_version", "editorconfig__handle_8h.html#abc0431223a6dc7b645d1aa9d05403d42", null ]
];