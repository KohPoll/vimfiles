var searchData=
[
  ['editorconfig_5fget_5ferror_5fmsg',['editorconfig_get_error_msg',['../editorconfig_8h.html#a779a54d57d57198a089ea7221751330c',1,'editorconfig.h']]],
  ['editorconfig_5fget_5fversion',['editorconfig_get_version',['../editorconfig_8h.html#a388429db79c58c67f166a7daa026e695',1,'editorconfig.h']]],
  ['editorconfig_5fget_5fversion_5fsuffix',['editorconfig_get_version_suffix',['../editorconfig_8h.html#a353d4f1b9fd424c837a2efba6c6b02ad',1,'editorconfig.h']]],
  ['editorconfig_5fhandle_5fdestroy',['editorconfig_handle_destroy',['../editorconfig__handle_8h.html#add8960b396594d796843df56a6fd0cfe',1,'editorconfig_handle.h']]],
  ['editorconfig_5fhandle_5fget_5fconf_5ffile_5fname',['editorconfig_handle_get_conf_file_name',['../editorconfig__handle_8h.html#a5d8fd295880d6512751a7f3c840e3ce0',1,'editorconfig_handle.h']]],
  ['editorconfig_5fhandle_5fget_5ferr_5ffile',['editorconfig_handle_get_err_file',['../editorconfig__handle_8h.html#ae0c5207a1986dfea2f641008ddefdd93',1,'editorconfig_handle.h']]],
  ['editorconfig_5fhandle_5fget_5fname_5fvalue',['editorconfig_handle_get_name_value',['../editorconfig__handle_8h.html#ad8330caee21b6aaacfa9fc95792b0389',1,'editorconfig_handle.h']]],
  ['editorconfig_5fhandle_5fget_5fname_5fvalue_5fcount',['editorconfig_handle_get_name_value_count',['../editorconfig__handle_8h.html#a5a589c0471ca6651d09823595ddd3ea2',1,'editorconfig_handle.h']]],
  ['editorconfig_5fhandle_5fget_5fversion',['editorconfig_handle_get_version',['../editorconfig__handle_8h.html#a05b5ade439f00b2634a31c8b195365b7',1,'editorconfig_handle.h']]],
  ['editorconfig_5fhandle_5finit',['editorconfig_handle_init',['../editorconfig__handle_8h.html#a8e3f1681e835a2946ba93b341ebc3dca',1,'editorconfig_handle.h']]],
  ['editorconfig_5fhandle_5fset_5fconf_5ffile_5fname',['editorconfig_handle_set_conf_file_name',['../editorconfig__handle_8h.html#a345fc52f7cc06dc8d35685ef4904013b',1,'editorconfig_handle.h']]],
  ['editorconfig_5fhandle_5fset_5fversion',['editorconfig_handle_set_version',['../editorconfig__handle_8h.html#abc0431223a6dc7b645d1aa9d05403d42',1,'editorconfig_handle.h']]],
  ['editorconfig_5fparse',['editorconfig_parse',['../editorconfig_8h.html#add6bebe96bf90c48fef01cf5300ddf92',1,'editorconfig.h']]]
];
