var searchData=
[
  ['editorconfig_2eh',['editorconfig.h',['../editorconfig_8h.html',1,'']]],
  ['editorconfig_5fhandle_2eh',['editorconfig_handle.h',['../editorconfig__handle_8h.html',1,'']]]
];
